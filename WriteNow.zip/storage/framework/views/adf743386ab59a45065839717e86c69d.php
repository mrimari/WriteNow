

<?php $__env->startSection('style'); ?>
<style>
    .card {
        border-radius: 18px;
        box-shadow: 0 2px 12px 0 rgba(0,0,0,0.08);
        margin-bottom: 24px;
        border: none;
        background: #fff8f0;
    }
    .card-header, .card-body {
        background: transparent;
    }
    .achievement-icon i, .report-item i {
        color: #ffb300;
        filter: drop-shadow(0 2px 4px rgba(0,0,0,0.08));
    }
    .btn-outline-primary, .btn-outline-secondary, .btn-outline-danger, .btn-success, .btn-danger {
        border-radius: 10px;
        font-weight: 500;
        min-width: 110px;
        margin: 2px 0;
    }
    .btn-outline-primary:hover, .btn-outline-secondary:hover, .btn-outline-danger:hover, .btn-success:hover, .btn-danger:hover {
        filter: brightness(0.95);
        transform: scale(1.04);
        transition: 0.2s;
    }
    .card-title {
        color: #975a1c;
        font-weight: bold;
        font-size: 1.2rem;
    }
    .card-text, .text-muted {
        color: #6c757d;
    }
    .user-avatar img, .avatar-placeholder {
        width: 40px;
        height: 40px;
        object-fit: cover;
        border-radius: 50%;
        border: 2px solid #ffb300;
        background: #fff;
    }
    .user-item {
        background: #f8f9fa;
        border-radius: 12px;
        box-shadow: 0 1px 4px rgba(0,0,0,0.05);
    }
    .pagination .page-link {
        border-radius: 8px !important;
        color: #975a1c;
    }
    .pagination .page-item.active .page-link {
        background: #975a1c;
        color: #fff;
        border: none;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container" style="z-index: 10; position: relative;">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Достижения <?php echo e($user->name); ?></h5>
                    <a href="<?php echo e(route('profile')); ?>" class="btn btn-sm btn-outline-secondary">Назад к профилю</a>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $achievements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achievement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-md-6 mb-4">
                                <div class="card h-100">
                                    <div class="card-body">
                                        <div class="d-flex align-items-center mb-3">
                                            <div class="achievement-icon me-3">
                                                <i class="fas fa-trophy fa-2x text-warning"></i>
                                            </div>
                                            <div>
                                                <h5 class="card-title mb-1"><?php echo e($achievement->name); ?></h5>
                                                <p class="card-text text-muted mb-0">
                                                    Получено: <?php echo e($achievement->pivot->unlocked_at ? \Illuminate\Support\Carbon::parse($achievement->pivot->unlocked_at)->format('d.m.Y H:i') : '-'); ?>

                                                </p>
                                            </div>
                                        </div>
                                        <p class="card-text"><?php echo e($achievement->description); ?></p>
                                        <a href="<?php echo e(route('achievements.show', $achievement)); ?>" class="btn btn-outline-primary btn-sm">
                                            Подробнее
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-12">
                                <p class="text-center mb-0">У пользователя пока нет достижений</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="d-flex justify-content-center">
                        <?php echo e($achievements->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Diplom\NewWriteNow\WriteNow\resources\views/achievements/user.blade.php ENDPATH**/ ?>