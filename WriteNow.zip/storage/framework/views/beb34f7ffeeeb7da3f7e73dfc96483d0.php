

<?php $__env->startSection('content'); ?>
<div class="container" style="z-index: 10;">
    <h1 class="mb-4">Жалобы</h1>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Пользователь</th>
                <th>На что</th>
                <th>Причина</th>
                <th>Описание</th>
                <th>Статус</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($report->id); ?></td>
                    <td><?php echo e($report->user->name ?? '—'); ?></td>
                    <td>
                        <?php if($report->reportable): ?>
                            <?php if($report->reportable_type === 'App\\Models\\Post'): ?>
                                Пост: <a href="<?php echo e(route('posts.show', $report->reportable_id)); ?>">#<?php echo e($report->reportable_id); ?></a>
                            <?php else: ?>
                                <?php echo e(class_basename($report->reportable_type)); ?>: #<?php echo e($report->reportable_id); ?>

                            <?php endif; ?>
                        <?php else: ?>
                            —
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($report->reason); ?></td>
                    <td><?php echo e($report->description); ?></td>
                    <td><?php echo e($report->status); ?></td>
                    <td>
                        <?php if($report->status === 'pending'): ?>
                            <form action="<?php echo e(route('reports.resolve', $report)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-success">Принять</button>
                            </form>
                            <form action="<?php echo e(route('reports.reject', $report)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-danger">Отклонить</button>
                            </form>
                        <?php else: ?>
                            <span>—</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div>
        <?php echo e($reports->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Diplom\NewWriteNow\WriteNow\resources\views/admin/reports/index.blade.php ENDPATH**/ ?>