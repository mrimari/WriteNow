
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/katalog.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form action="" class="search_form">
        <input class="search_input" type="text" name="search" placeholder="Введите название" value="">

        <select name="" id="" class="genre">
            <option value="">Все жанры</option>
            <option value="">Романтика</option>
            <option value="">Фантастика</option>
        </select>
        <select name="" id="" class="forma">
            <option value="">Все формы</option>
            <option value="">Стихотворение</option>
            <option value="">Проза</option>
        </select>
        <input class="id_input" type="text" name="search" placeholder="id книги" value="">
        <button class="search_button">Поиск</button>
        <button type="submit" name="filter" class="all_works">Все</button>
        <button type="submit" name="filter" class="new_works">Новое</button>
        <button type="submit" name="filter" class="old_works">Старые</button>
    </form>

    <div class="katalog">
        <div class="card">
            <div class="proizv">
                <h2 class="title">Зимний вечер</h2>
                <p class="form">стихотворение</p>
                <p class="description">*Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veniam ratione
                    nisi modi nam dolores? Ea atque sit similique eveniet ullam quaerat placeat reprehenderit
                    ipsa incidunt quia, perspiciatis ratione commodi quae span</p>*
            </div>
            <div class="card_footer">
                <a href=""><img class="foto" src="<?php echo e('images/pushkin.png'); ?>" alt="Пушкин">
                </a>
                <div class="author_info">
                    <a href="" class="name_author">Пушкин</a>
                    <a href="" class="writer">Поэт</a>
                </div>
                <div class="likes">
                    <img class="like" src="<?php echo e('images/like.svg'); ?>" alt="">
                    <span class="num">99</span>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="proizv">
                <h2 class="title">Зимний вечер</h2>
                <p class="form">стихотворение</p>
                <p class="description">*Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veniam ratione
                    nisi modi nam dolores? Ea atque sit similique eveniet ullam quaerat placeat reprehenderit
                    ipsa incidunt quia, perspiciatis ratione commodi quae span</p>*
            </div>
            <div class="card_footer">
                <a href=""><img class="foto" src="<?php echo e('images/pushkin.png'); ?>" alt="Пушкин">
                </a>
                <div class="author_info">
                    <a href="" class="name_author">Пушкин</a>
                    <a href="" class="writer">Поэт</a>
                </div>
                <div class="likes">
                    <img class="like" src="<?php echo e('images/like.svg'); ?>" alt="">
                    <span class="num">99</span>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="proizv">
                <h2 class="title">Зимний вечер</h2>
                <p class="form">стихотворение</p>
                <p class="description">*Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veniam ratione
                    nisi modi nam dolores? Ea atque sit similique eveniet ullam quaerat placeat reprehenderit
                    ipsa incidunt quia, perspiciatis ratione commodi quae span</p>*
            </div>
            <div class="card_footer">
                <a href=""><img class="foto" src="<?php echo e('images/pushkin.png'); ?>" alt="Пушкин">
                </a>
                <div class="author_info">
                    <a href="" class="name_author">Пушкин</a>
                    <a href="" class="writer">Поэт</a>
                </div>
                <div class="likes">
                    <img class="like" src="<?php echo e('images/like.svg'); ?>" alt="">
                    <span class="num">99</span>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="proizv">
                <h2 class="title">Зимний вечер</h2>
                <p class="form">стихотворение</p>
                <p class="description">*Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veniam ratione
                    nisi modi nam dolores? Ea atque sit similique eveniet ullam quaerat placeat reprehenderit
                    ipsa incidunt quia, perspiciatis ratione commodi quae span</p>*
            </div>
            <div class="card_footer">
                <a href=""><img class="foto" src="<?php echo e('images/pushkin.png'); ?>" alt="Пушкин">
                </a>
                <div class="author_info">
                    <a href="" class="name_author">Пушкин</a>
                    <a href="" class="writer">Поэт</a>
                </div>
                <div class="likes">
                    <img class="like" src="<?php echo e('images/like.svg'); ?>" alt="">
                    <span class="num">99</span>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="proizv">
                <h2 class="title">Зимний вечер</h2>
                <p class="form">стихотворение</p>
                <p class="description">*Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veniam ratione
                    nisi modi nam dolores? Ea atque sit similique eveniet ullam quaerat placeat reprehenderit
                    ipsa incidunt quia, perspiciatis ratione commodi quae span</p>*
            </div>
            <div class="card_footer">
                <a href=""><img class="foto" src="<?php echo e('images/pushkin.png'); ?>" alt="Пушкин">
                </a>
                <div class="author_info">
                    <a href="" class="name_author">Пушкин</a>
                    <a href="" class="writer">Поэт</a>
                </div>
                <div class="likes">
                    <img class="like" src="<?php echo e('images/like.svg'); ?>" alt="">
                    <span class="num">99</span>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="proizv">
                <h2 class="title">Зимний вечер</h2>
                <p class="form">стихотворение</p>
                <p class="description">*Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veniam ratione
                    nisi modi nam dolores? Ea atque sit similique eveniet ullam quaerat placeat reprehenderit
                    ipsa incidunt quia, perspiciatis ratione commodi quae span</p>*
            </div>
            <div class="card_footer">
                <a href=""><img class="foto" src="<?php echo e('images/pushkin.png'); ?>" alt="Пушкин">
                </a>
                <div class="author_info">
                    <a href="" class="name_author">Пушкин</a>
                    <a href="" class="writer">Поэт</a>
                </div>
                <div class="likes">
                    <img class="like" src="<?php echo e('images/like.svg'); ?>" alt="">
                    <span class="num">99</span>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="proizv">
                <h2 class="title">Зимний вечер</h2>
                <p class="form">стихотворение</p>
                <p class="description">*Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veniam ratione
                    nisi modi nam dolores? Ea atque sit similique eveniet ullam quaerat placeat reprehenderit
                    ipsa incidunt quia, perspiciatis ratione commodi quae span</p>*
            </div>
            <div class="card_footer">
                <a href=""><img class="foto" src="<?php echo e('images/pushkin.png'); ?>" alt="Пушкин">
                </a>
                <div class="author_info">
                    <a href="" class="name_author">Пушкин</a>
                    <a href="" class="writer">Поэт</a>
                </div>
                <div class="likes">
                    <img class="like" src="<?php echo e('images/like.svg'); ?>" alt="">
                    <span class="num">99</span>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="proizv">
                <h2 class="title">Зимний вечер</h2>
                <p class="form">стихотворение</p>
                <p class="description">*Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veniam ratione
                    nisi modi nam dolores? Ea atque sit similique eveniet ullam quaerat placeat reprehenderit
                    ipsa incidunt quia, perspiciatis ratione commodi quae span</p>*
            </div>
            <div class="card_footer">
                <a href=""><img class="foto" src="<?php echo e('images/pushkin.png'); ?>" alt="Пушкин">
                </a>
                <div class="author_info">
                    <a href="" class="name_author">Пушкин</a>
                    <a href="" class="writer">Поэт</a>
                </div>
                <div class="likes">
                    <img class="like" src="<?php echo e('images/like.svg'); ?>" alt="">
                    <span class="num">99</span>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="proizv">
                <h2 class="title">Зимний вечер</h2>
                <p class="form">стихотворение</p>
                <p class="description">*Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veniam ratione
                    nisi modi nam dolores? Ea atque sit similique eveniet ullam quaerat placeat reprehenderit
                    ipsa incidunt quia, perspiciatis ratione commodi quae span</p>*
            </div>
            <div class="card_footer">
                <a href=""><img class="foto" src="<?php echo e('images/pushkin.png'); ?>" alt="Пушкин">
                </a>
                <div class="author_info">
                    <a href="" class="name_author">Пушкин</a>
                    <a href="" class="writer">Поэт</a>
                </div>
                <div class="likes">
                    <img class="like" src="<?php echo e('images/like.svg'); ?>" alt="">
                    <span class="num">99</span>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Diplom\NewWriteNow\WriteNow\resources\views/katalog.blade.php ENDPATH**/ ?>