<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <section class="container_1">
            <p class="block1_1">
                Платформа вашего <span class="hightlight">творчества</span>
            </p>
            <p class="block2_1">
                Пространство для вдохновения и творчества
            </p>
            <a href="<?php echo e(route('posts')); ?>" class="block3_1 button">Читать</a>
            <a href="<?php echo e(route('create_post')); ?>" class="block4_1 button">Творить</a>
        </section>
        <section class="container_2">
            <div class="offer">
                <h1>Мы <span class="hightlight">вам</span> предлагаем</h1>
                <div class="block1_2">
                    <img class="icon" src="<?php echo e('images/prodvizh.svg'); ?>" alt="">
                    <p class="title">Продвижение</p>
                    <p>Узнаваемость автора и ажиотаж вокруг его произведений</p>
                </div>
                <div class="block2_2">
                    <img class="icon" src="<?php echo e('images/support.svg'); ?>" alt="">
                    <p class="title">Круглосоточная поддержка</p>
                    <p>Обращайтесь в любое время. Ответ от администраторов не заставит долго ждать</p>
                </div>
                <div class="block3_2">
                    <img class="icon" src="<?php echo e('images/formats.svg'); ?>" alt="">
                    <p class="title">Свобода форматов и жанров</p>
                    <p>Публикуйте свои произведения в любых жанрах и в любых размерах</p>
                </div>
            </div>
        </section>
        <section class="container_3">
            <h1>Популярные <span class="hightlight">произведения</span></h1>
            <div class="popular">
                <?php $__currentLoopData = $popularPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card">
                        <div class="proizv">
                            <h2 class="title"><?php echo e($post->title); ?></h2>
                            <p class="form"><?php echo e($post->form); ?></p>
                            <p class="description">*<?php echo e($post->content); ?></p>*
                        </div>
                        <div class="card_footer">
                            <a href="<?php echo e(route('showUser', ['user' => $post->user->id])); ?>">
                                <img class="foto" src="<?php echo e(asset('storage/avatars/' . ($post->user->avatar ?? 'default-avatar.svg'))); ?>" alt="<?php echo e($post->user->name); ?>">
                            </a>
                            <div class="author_info">
                                <a href="<?php echo e(route('showUser', ['user' => $post->user->id])); ?>" class="name_author"><?php echo e($post->user->name); ?></a>
                            </div>
                            <div class="likes">
                                <img class="like" src="<?php echo e('images/like.svg'); ?>" alt="">
                                <span class="num"><?php echo e($post->likes_count - $post->dislikes_count); ?></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
        <section class="container_4">
            <h1><span class="hightlight">Статистика</span> платформы</h1>
            <div class="statistic">
                <div class="users">
                    <p class="statistic_users"><?php echo e($usersCount); ?></p>
                    <img src="<?php echo e('images/Group.svg'); ?>" alt="" class="users_svg">
                </div>
                <div class="svg_statistic">
                    <img src="<?php echo e('images/statistic.svg'); ?>" alt="тут должна быть иконка">
                </div>
                <div class="works">
                    <p class="statistic_works"><?php echo e($postsCount); ?></p>
                    <img src="<?php echo e('images/Group2.svg'); ?>" alt="" class="works_svg">
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Diplom\NewWriteNow\WriteNow\resources\views/home.blade.php ENDPATH**/ ?>