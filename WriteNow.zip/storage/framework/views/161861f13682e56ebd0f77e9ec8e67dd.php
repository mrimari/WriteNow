<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/profile.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="profile">
        <img class="profile_png" src="<?php echo e(asset('storage/avatars/' . ($user->avatar ?? 'default-avatar.png'))); ?>" alt="">
        <div class="dropdown">
            <div class="dropdown_btn">
                <div class="pointer"></div>
                <div class="pointer"></div>
                <div class="pointer"></div>
            </div>
            <div class="dropdown_content">
                <a href="<?php echo e(route('users.following', Auth::user())); ?>">Мои подписки</a>
                <a href="<?php echo e(route('edit_profile')); ?>">Изменить профиль</a>
                <?php if(Auth::user() && Auth::user()->is_admin): ?>
                    <a href="<?php echo e(route('admin.dashboard')); ?>">Админка</a>
                <?php endif; ?>
                <form action="<?php echo e(route('profile.destroy')); ?>" method="POST"
                    onsubmit="return confirm('Вы уверены, что хотите удалить свой профиль? Это действие нельзя отменить.');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Удалить профиль</button>
                </form>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button href="">Выйти</button>
                </form>
            </div>
        </div>

        <h3 class="title_profile"><?php echo e($user->name); ?></h3>

        <div class="subscription-info">
            <a href="<?php echo e(route('users.followers', $user)); ?>" class="followers-link">
                Подписчики: <span class="followers-count"><?php echo e($user->followers()->count()); ?></span>
            </a>
            <?php if(Auth::check() && Auth::id() !== $user->id): ?>
                <?php if(Auth::user()->isFollowing($user)): ?>
                    <form action="<?php echo e(route('users.unfollow', $user)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="unfollow-btn">Отписаться</button>
                    </form>
                <?php else: ?>
                    <form action="<?php echo e(route('users.follow', $user)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="follow-btn">Подписаться</button>
                    </form>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <p class="light">О себе</p>
        <p class="info"><?php echo e($user->about); ?></p>
        <p class="light">Соц. сети:</p>
        <p class="info">ВК - <?php echo e($user->vk_link); ?>, ТГ - <?php echo e($user->tg_link); ?>;</p>
    </div>

    <div class="works">
        <p class="title_works">Работ: <span class="light_num"><?php echo e($posts->total()); ?></span></p>
        <a href="<?php echo e(route('drafts')); ?>" class="chernovik_btn">Черновик</a>
        <a href="<?php echo e(route('create_post')); ?>" class="new_btn">Создать</a>
    </div>

    <div class="katalog">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="/posts/<?php echo e($post->id); ?>" class="card">
                <div class="proizv">
                    <h2 class="title_proizv"><?php echo e($post->title); ?></h2>
                    <p class="form"><?php echo e($post->form); ?></p>
                    <p class="description">*<?php echo e($post->content); ?></p>*
                </div>
                <div class="card_footer">
                    <p class="time"><?php echo e($post->created_at->format('d.m.Y')); ?></p>
                    <div class="likes">
                        <img class="like" src="<?php echo e('images/like.svg'); ?>" alt="">
                        <span class="num"><?php echo e($post->likes_count - $post->dislikes_count); ?></span>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="pagination">
        <?php echo e($posts->links()); ?>

    </div>

    <script>
        // JavaScript для открытия/закрытия выпадающего списка
        document.querySelector('.dropdown_btn').addEventListener('click', function () {
            const dropdown = this.closest('.dropdown');
            dropdown.classList.toggle('active');
        });

        // Закрыть выпадающий список при клике вне его
        document.addEventListener('click', function (event) {
            const dropdowns = document.querySelectorAll('.dropdown');
            dropdowns.forEach(dropdown => {
                if (!dropdown.contains(event.target)) {
                    dropdown.classList.remove('active');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Diplom\NewWriteNow\WriteNow\resources\views/profile.blade.php ENDPATH**/ ?>