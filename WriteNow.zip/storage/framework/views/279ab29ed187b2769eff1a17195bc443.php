
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/edit_profile.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('edit_profile')); ?>" class="content" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <h1 class="title">Редактирование профиля</h1>
        <div class="image-upload">
            <img id="preview" src="<?php echo e(asset('storage/avatars/' . auth()->user()->avatar)); ?>" alt="Фото">
            <input type="file" id="avatar" name="avatar">
        </div>
        <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div class="input">
            <div class="group">
                <label for="name">Имя</label>
                <input type="text" placeholder="" value="<?php echo e(old('name', auth()->user()->name)); ?>" id="name" name="name">
            </div>
            <div class="group">
                <label for="current_password">Старый пароль</label>
                <input type="password" id="current_password" name="current_password">
            </div>
            <div class="group">
                <label for="vk_link">Соц. сети</label>
                <div class="social">
                    <label for="vk_link">Вк-</label>
                    <input type="text" placeholder="" id="vk_link" name="vk_link"
                        value="<?php echo e(old('vk_link', auth()->user()->vk_link)); ?>">
                    <label for="tg_link">Тг-</label>
                    <input type="text" placeholder="" id="tg_link" name="tg_link"
                        value="<?php echo e(old('tg_link', auth()->user()->tg_link)); ?>">
                </div>
            </div>
            <div class="group">
                <label for="new_password">Новый пароль</label>
                <input type="password" placeholder="" id="new_password" name="new_password">
            </div>
            <div class="group about">
                <label for="about">О себе</label>
                <textarea name="about" id="about"><?php echo e(old('about', auth()->user()->about)); ?></textarea>
            </div>
            <button type="submit" class="form_btn">
                Сохранить изменения
            </button>
        </div>


    </form>

    <script>
        const fileInput = document.getElementById('avatar');
        const preview = document.getElementById('preview');

        fileInput.addEventListener('change', function (e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function (event) {
                    preview.src = event.target.result;
                };
                reader.readAsDataURL(file);
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Diplom\NewWriteNow\WriteNow\resources\views/edit_profile.blade.php ENDPATH**/ ?>