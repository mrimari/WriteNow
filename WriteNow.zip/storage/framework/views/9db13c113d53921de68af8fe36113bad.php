
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/work.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="work">
        <h1 class="title_work">Мое произведение</h1>
        <div class="like-container">
            <!-- Сердце -->
            <div class="heart" id="heart"></div>
            <!-- Счетчик лайков -->
            <span id="likeCount">0</span>
        </div>
        <div class="content_work" id="content_work">dasdadasd</div>
        <div id="pageInfo" class="pageInfo"></div>
        <div id="pagination" class="pagination">
            <button id="prevPage">Предыдущая</button>
            <button id="nextPage">Следующая</button>
        </div>

    </div>

    <script>
        const text = `

                                        `.trim();

        // Настройки пагинации
        let currentPage = 1; // Текущая страница
        const linesPerPage = 100; // Количество строк на страницу

        // Элементы DOM
        const contentElement = document.getElementById("content_work");
        const prevPageButton = document.getElementById("prevPage");
        const nextPageButton = document.getElementById("nextPage");
        const pageInfoElement = document.getElementById("pageInfo");

        // Разделение текста на строки
        const lines = text.split('\n');

        // Функция для обновления отображаемого текста
        function updateContent() {
            const start = (currentPage - 1) * linesPerPage;
            const end = start + linesPerPage;
            const visibleLines = lines.slice(start, end);
            contentElement.textContent = visibleLines.join('\n');
        }

        // Функция для обновления состояния кнопок и информации о странице
        function updatePagination() {
            const totalPages = Math.ceil(lines.length / linesPerPage);

            // Обновляем информацию о текущей странице
            pageInfoElement.textContent = `Страница ${currentPage} из ${totalPages}`;

            // Блокируем кнопки, если страница первая или последняя
            prevPageButton.disabled = currentPage <= 1;
            nextPageButton.disabled = currentPage >= totalPages;
        }

        // Переход на предыдущую страницу
        prevPageButton.addEventListener("click", () => {
            if (currentPage > 1) {
                currentPage--;
                updateContent();
                updatePagination();
            }
        });

        // Переход на следующую страницу
        nextPageButton.addEventListener("click", () => {
            const totalPages = Math.ceil(lines.length / linesPerPage);
            if (currentPage < totalPages) {
                currentPage++;
                updateContent();
                updatePagination();
            }
        });

        // Инициализация при загрузке страницы
        updateContent();
        updatePagination();

        // likeeeeeeeeeeeeee
        // Элементы DOM
        const heart = document.getElementById("heart");
        const likeCountElement = document.getElementById("likeCount");

        // Состояние лайка
        let isLiked = false;
        let likeCount = 0;

        // Обработчик клика на сердце
        heart.addEventListener("click", () => {
            // Переключаем состояние лайка
            isLiked = !isLiked;

            // Обновляем счетчик лайков
            if (isLiked) {
                likeCount++;
            } else {
                likeCount--;
            }

            // Обновляем отображение
            updateLikeState();
        });

        // Функция для обновления состояния лайка
        function updateLikeState() {
            // Обновляем класс сердца
            heart.classList.toggle("liked", isLiked);

            // Добавляем анимацию
            heart.classList.add("animate");
            setTimeout(() => {
                heart.classList.remove("animate");
            }, 400);

            // Обновляем счетчик лайков
            likeCountElement.textContent = likeCount;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Diplom\NewWriteNow\WriteNow\resources\views/posts/work.blade.php ENDPATH**/ ?>