

<?php $__env->startSection('content'); ?>
<div class="followers-page" style="z-index: 10;">
    <h2>Подписчики <?php echo e($user->name); ?></h2>
    
    <div class="followers-list">
        <?php $__empty_1 = true; $__currentLoopData = $followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="follower-card">
                <img src="<?php echo e(asset('storage/avatars/' . ($follower->avatar ?? 'default-avatar.svg'))); ?>" alt="<?php echo e($follower->name); ?>" class="follower-avatar">
                <div class="follower-info">
                    <a href="<?php echo e(route('showUser', $follower)); ?>" class="follower-name"><?php echo e($follower->name); ?></a>
                    <p class="follower-about"><?php echo e(Str::limit($follower->about, 100)); ?></p>
                </div>
                <?php if(Auth::check() && Auth::id() !== $follower->id): ?>
                    <?php if(Auth::user()->isFollowing($follower)): ?>
                        <form action="<?php echo e(route('users.unfollow', $follower)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="unfollow-btn">Отписаться</button>
                        </form>
                    <?php else: ?>
                        <form action="<?php echo e(route('users.follow', $follower)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="follow-btn">Подписаться</button>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="no-followers">У этого пользователя пока нет подписчиков</p>
        <?php endif; ?>
    </div>

    <div class="pagination">
        <?php echo e($followers->links()); ?>

    </div>
</div>

<style>
.followers-page {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
}

.followers-page h2 {
    margin-bottom: 20px;
    color: #333;
}

.followers-list {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.follower-card {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 15px;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.follower-avatar {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    object-fit: cover;
}

.follower-info {
    flex-grow: 1;
}

.follower-name {
    font-size: 18px;
    font-weight: bold;
    color: #333;
    text-decoration: none;
}

.follower-name:hover {
    color: #666;
}

.follower-about {
    color: #666;
    margin-top: 5px;
    font-size: 14px;
}

.no-followers {
    text-align: center;
    color: #666;
    padding: 20px;
}

.pagination {
    margin-top: 20px;
    display: flex;
    justify-content: center;
}
</style>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Diplom\NewWriteNow\WriteNow\resources\views/users/followers.blade.php ENDPATH**/ ?>