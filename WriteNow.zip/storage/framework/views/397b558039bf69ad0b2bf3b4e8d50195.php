<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/drafts.css')); ?>">
    <title>Черновики</title>
</head>

<body>
    <div class="background">
        <section class="header_edit">
            <a class="logo_edit" href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="Логотип компании">
            </a>
            <a href="<?php echo e(url()->previous()); ?>" class="back">
                🠔 Вернуться
            </a>
        </section>
        <section class="content">
            <div class="header_content">
                <p>Пользователь</p>
                <p>Название</p>
                <p>Дата</p>
                <p>Статус</p>
                <p>Публикация</p>
            </div>
            <hr class="line_content">
            <?php $__empty_1 = true; $__currentLoopData = $drafts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $draft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="content_content">
                    <p><?php echo e($draft->user->name); ?></p>
                    <p><?php echo e($draft->title); ?></p>
                    <p><?php echo e($draft->created_at->format('d.m.Y')); ?></p>
                    <p>Черновик</p>
                    <a href="<?php echo e(route('posts.edit', $draft)); ?>" class="btn_content">Редактировать</a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="content_content">
                    <p colspan="5">У вас нет черновиков</p>
                </div>
            <?php endif; ?>
        </section>
    </div>
</body>

</html><?php /**PATH D:\Diplom\NewWriteNow\WriteNow\resources\views/drafts.blade.php ENDPATH**/ ?>