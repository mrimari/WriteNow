<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/creat.css')); ?>">
    <title>Document</title>
</head>

<body>
    <div class="background">
        <section class="header_edit">
            <a class="logo_edit" href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="Логотип компании">
            </a>
            <a href="" class="back">
                <img src="<?php echo e(asset('images/Arrow.svg')); ?>" alt="Логотип компании">
                <p>Назад</p>
            </a>
        </section>
        <form method="POST" action="<?php echo e(route('create_post')); ?>" class="content">
            <?php echo csrf_field(); ?>
            <input type="text" class="title_input" name="title" placeholder="Введите название" value="">
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <textarea name="content" id="" class="content_content"></textarea>
            <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <select name="genre" id="" class="genre" required>
                <option value="">Жанр</option>
                <option value="Roman">Романтика</option>
                <option value="Fantazy">Фантастика</option>
            </select>
            <?php $__errorArgs = ['genre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <select name="form" id="" class="forma" required>
                <option value="">Форма</option>
                <option value="Stih">Стихотворение</option>
                <option value="Proza">Проза</option>
            </select>
            <?php $__errorArgs = ['format'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <button type="submit" class="btn_content">Опубликовать</button>
            <button class="btn_content">В черновик</button>
            <button class="btn_content">Копирайтеру</button>
        </form>
    </div>
</body>

</html><?php /**PATH D:\Diplom\NewWriteNow\WriteNow\resources\views/create_post.blade.php ENDPATH**/ ?>