
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/posts.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form method="GET" action="<?php echo e(route('posts')); ?>" class="search_form">
        <?php echo csrf_field(); ?>
        <input value="<?php echo e(request('search')); ?>" class="search_input" type="text" name="search_title" placeholder="Введите название"
            value="">

        <select name="genre" id="" class="genre">
            <option value="">Все жаанры</option>
            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($genre); ?>" <?php echo e(request('genre') == $genre ? 'selected' : ''); ?>>
                    <?php echo e($genre); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <select name="form" id="" class="forma">
            <option value="">Все формы</option>
            <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($form); ?>" <?php echo e(request('form') == $form ? 'selected' : ''); ?>>
                    <?php echo e($form); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input class="id_input" type="text" placeholder="id произведения" value="<?php echo e(request('search_id')); ?>" name="search_id">
        <button class="search_button">Поиск</button>
        <button type="submit" name="filter" value="all" class="all_works">Все</button>
        <button type="submit" name="filter" value="new" class="new_works">Новые</button>
        <button type="submit" name="filter" value="old" class="old_works">Старые</button>
    </form>

    <div class="katalog">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="/posts/<?php echo e($post->id); ?>" class="card">
                <div class="proizv">
                    <h2 class="title_proizv"><?php echo e($post->title); ?></h2>
                    <p class="form"><?php echo e($post->form); ?></p>
                    <p class="description">*<?php echo e($post->content); ?></p>*
                </div>
                <div class="card_footer">
                    <div class="author_photo">
                        <img class="foto" src="<?php echo e(asset('storage/avatars/' . ($post->user->avatar ?? 'default-avatar.svg'))); ?>"
                            alt="Пушкин">
                    </div>
                    <div class="author_info">
                        <span class="name_author"><?php echo e($post->user->name); ?></span>
                        <span class="writer">Поэт</span>
                    </div>
                    <div class="likes">
                        <img class="like" src="<?php echo e('images/like.svg'); ?>" alt="">
                        <span class="num"><?php echo e($post->likes_count - $post->dislikes_count); ?></span>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="pagination">
        <?php echo e($posts->appends(request()->query())->links()); ?>

    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Diplom\NewWriteNow\WriteNow\resources\views/posts/posts.blade.php ENDPATH**/ ?>