<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Сайт</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/global.css')); ?>">
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body>
    <div class="background">
        <header class="header">
            <div class="nav">
                <a class="logo_header" href="<?php echo e(route('home')); ?>">
                    <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="Логотип компании">
                </a>
                <a href="<?php echo e(route('posts')); ?>" class="nav_link <?php echo e(request()->routeIs('posts') ? 'active' : ''); ?>" id="katalog">Открой</a>
                <a href="<?php echo e(route('users')); ?>" class="nav_link <?php echo e(request()->routeIs('users') ? 'active' : ''); ?>">Творцы</a>
                <a href="" class="nav_link <?php echo e(request()->routeIs('about_us') ? 'active' : ''); ?>">О нас</a>
                <?php if(Auth::check()): ?>
                    <a href="<?php echo e(route('profile')); ?>" class="profile_img">
                        <img src="<?php echo e(asset('images/profile.svg')); ?>" alt="Логотип компании">
                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('auth')); ?>" class="header_btn">
                        Войти
                    </a>
                <?php endif; ?>

            </div>
        </header>
        <?php echo $__env->yieldContent('content'); ?>
        <footer class="footer">
            <div class="left_line">

            </div>
            <a class="logo_footer" href="">
                <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="Логотип компании">
            </a>
            <div class="right_line">

            </div>
            <div class="pages">
                <a href="">Главная</a>
                <a href="">Произведения</a>
                <a href="">О нас</a>
                <a href="">Творцы</a>
            </div>
            <div class="mid_line">

            </div>
            <div class="politic">
                <a href="<?php echo e(route('privacy-policy')); ?>">Политика конфиденциальности</a>
                <a href="<?php echo e(route('terms')); ?>">Правила и условия</a>
            </div>
            <div class="social">
                <a class="tg" href="">
                    <img src="<?php echo e(asset('images/tg.svg')); ?>" alt="Логотип компании">
                </a>
                <a class="vk" href="">
                    <img src="<?php echo e(asset('images/vk.svg')); ?>" alt="Логотип компании">
                </a>
                <a class="mail" href="">
                    <img src="<?php echo e(asset('images/mail.svg')); ?>" alt="Логотип компании">
                </a>
            </div>
            <p class="©">© 2024 WriteNow. Все права защищены</p>

        </footer>
    </div>
</body>

</html><?php /**PATH D:\Diplom\NewWriteNow\WriteNow\resources\views/layouts/app.blade.php ENDPATH**/ ?>