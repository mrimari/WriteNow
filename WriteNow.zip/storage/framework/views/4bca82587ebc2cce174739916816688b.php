<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/reg.css')); ?>">
    <title>Document</title>
</head>

<body>
    <div class="background">
        <div class="content">
            <form method="POST" class="reg" action="<?php echo e(route('reg')); ?>">
                <?php echo csrf_field(); ?>
                    <a class="back_home" href="<?php echo e(route('home')); ?>">
                    🠔 На главную
                    </a>
                <h1 class="title_reg">Регистрация</h1>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <label for="email">Эл. почта:</label>
                <input type="text" id="email" name="email" required autofocus value="<?php echo e(old('email')); ?>"
                    class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="name">Ваше имя(будет видно другим):</label>
                <input type="text" id="name" name="name" required value="<?php echo e(old('name')); ?>"
                    class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="password">Придумайте пароль:</label>
                <input type="password" id="password" name="password" required
                    class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="password_confirmation">Повторите пароль:</label>
                <input type="password" id="password_confirmation" name="password_confirmation" required
                    class="<?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                <label for="captcha">Введите код с картинки:</label>
                <div class="captcha-wrapper">
                    <div id="captcha-text" class="captcha-text"></div>
                    <button type="button" id="refresh-captcha" class="refresh-captcha">↻</button>
                </div>
                <input type="text" id="captcha" name="captcha" required value="<?php echo e(old('captcha')); ?>"
                    class="<?php $__errorArgs = ['captcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['captcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="checkbox_reg">
                    <input type="checkbox" required <?php echo e(old('checkbox') ? 'checked' : ''); ?>>
                    <p>Согласие на обработку перс. данных</p>
                </div>
                <button class="btn_reg">Регистрация</button>
                <p class="auth">Есть аккаунт? <a href="<?php echo e(route('auth')); ?>" class="link_auth">Войти</a></p>
            </form>
        </div>
    </div>
    <script>
        function generateCaptcha() {
            fetch('<?php echo e(route("captcha.generate")); ?>')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('captcha-text').textContent = data.captcha;
                });
        }

        document.getElementById('refresh-captcha').addEventListener('click', generateCaptcha);
        generateCaptcha();
    </script>
</body>

</html><?php /**PATH D:\Diplom\NewWriteNow\WriteNow\resources\views/reg.blade.php ENDPATH**/ ?>