

<?php $__env->startSection('content'); ?>
<div class="container" style="z-index: 10;">
    <h1 class="mb-4">Посты</h1>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Заголовок</th>
                <th>Автор</th>
                <th>Дата</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($post->id); ?></td>
                    <td><?php echo e($post->title); ?></td>
                    <td><?php echo e($post->user->name ?? '—'); ?></td>
                    <td><?php echo e($post->created_at->format('d.m.Y H:i')); ?></td>
                    <td>
                        <form action="<?php echo e(route('admin.posts.delete', $post)); ?>" method="POST" style="display:inline-block;" onsubmit="return confirm('Удалить пост?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="hidden" name="reportable_type" value="App\Models\Post">
                            <button type="submit" class="btn btn-sm btn-danger">Удалить</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div>
        <?php echo e($posts->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Diplom\NewWriteNow\WriteNow\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>