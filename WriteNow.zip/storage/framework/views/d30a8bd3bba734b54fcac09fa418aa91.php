<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/creat.css')); ?>">
    <title>Document</title>
</head>

<body>
    <div class="background">
        <section class="header_edit">
            <a class="logo_edit" href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="Логотип компании">
            </a>
            <a href="" class="back">
                <img src="<?php echo e(asset('images/Arrow.svg')); ?>" alt="Логотип компании">
                <p>Назад</p>
            </a>
        </section>
        <form action="" class="content">
            <input type="text" class="title_input" name="title_input" placeholder="Введите название" value="">
            <textarea name="" id="" class="content_content"></textarea>
            <select name="" id="" class="genre">
                <option value="">Жанр</option>
                <option value="">Романтика</option>
                <option value="">Фантастика</option>
            </select>
            <select name="" id="" class="forma">
                <option value="">Форма</option>
                <option value="">Стихотворение</option>
                <option value="">Проза</option>
            </select>
            <button class="btn_content">Опубликовать</button>
            <button class="btn_content">В черновик</button>
            <button class="btn_content">Копирайтеру</button>
        </form>
    </div>
</body>

</html><?php /**PATH D:\Diplom\NewWriteNow\WriteNow\resources\views/create.blade.php ENDPATH**/ ?>