<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
    <title>Document</title>
</head>

<body>
    <div class="background">
        <div class="content">
            <form method="POST" action="<?php echo e(route('auth')); ?>" class="auth">
                <?php echo csrf_field(); ?>
                <a class="back_home" href="<?php echo e(route('home')); ?>">
                    🠔 На главную
                    </a>
                <h1 class="title_auth">Авторизация</h1>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <label for="email">Эл. почта:</label>
                <input type="text" id="email" name="email" value="<?php echo e(old('email')); ?>"
                    class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="password">Пароль:</label>
                <input type="password" id="password" name="password" class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                <label for="captcha">Введите код с картинки:</label>
                <div class="captcha-wrapper">
                    <div id="captcha-text" class="captcha-text"></div>
                    <button type="button" id="refresh-captcha" class="refresh-captcha">↻</button>
                </div>
                <input type="text" id="captcha" name="captcha" required value="<?php echo e(old('captcha')); ?>"
                    class="<?php $__errorArgs = ['captcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['captcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <button class="btn_auth">Войти</button>
                <p class="reg">Есть аккаунт? <a href="<?php echo e(route('reg')); ?>" class="link_reg">Регистрация</a></p>
            </form>
        </div>
    </div>
    <script>
        function generateCaptcha() {
            fetch('<?php echo e(route("captcha.generate")); ?>')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('captcha-text').textContent = data.captcha;
                });
        }

        document.getElementById('refresh-captcha').addEventListener('click', generateCaptcha);
        generateCaptcha();
    </script>
</body>

</html><?php /**PATH D:\Diplom\NewWriteNow\WriteNow\resources\views/auth.blade.php ENDPATH**/ ?>