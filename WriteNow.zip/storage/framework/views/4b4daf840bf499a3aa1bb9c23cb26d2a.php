
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/authors.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form action="" class="search_form">
        <input class="search_input" type="text" name="search" placeholder="Введите название" value="">
        <button class="search_button">Поиск</button>
        <button type="submit" name="filter" class="all_works">Все</button>
        <button type="submit" name="filter" class="new_works">Новые</button>
    </form>
    <section class="authors">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="author">
            <img class="author_img" src="<?php echo e(asset('storage/avatars/' . ($user->avatar ?? 'default-avatar.svg'))); ?>" alt="">
            <h2 class="title"><?php echo e($user->name); ?></h2>
            <a href="<?php echo e(route('showUser')); ?>" class="author_link">Профиль</a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Diplom\NewWriteNow\WriteNow\resources\views/authors.blade.php ENDPATH**/ ?>