

<?php $__env->startSection('content'); ?>
<div class="container" style="z-index: 10;">
    <h1 class="mb-4">Пользователи</h1>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Имя</th>
                <th>Email</th>
                <th>Админ</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->is_admin ? 'Да' : 'Нет'); ?></td>
                    <td>
                        <form action="<?php echo e(route('admin.users.toggle-admin', $user)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-sm btn-warning">
                                <?php echo e($user->is_admin ? 'Снять админа' : 'Сделать админом'); ?>

                            </button>
                        </form>
                        <form action="<?php echo e(route('admin.users.delete', $user)); ?>" method="POST" style="display:inline-block;" onsubmit="return confirm('Удалить пользователя?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger">Удалить</button>
                        </form>
                        <?php if(!$user->banned): ?>
                            <form action="<?php echo e(route('admin.users.ban', $user)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-secondary">Забанить</button>
                            </form>
                        <?php else: ?>
                            <form action="<?php echo e(route('admin.users.unban', $user)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-success">Разбанить</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div>
        <?php echo e($users->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Diplom\NewWriteNow\WriteNow\resources\views/admin/users/index.blade.php ENDPATH**/ ?>