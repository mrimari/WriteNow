<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/create_post.css')); ?>">
    <title>Редактировать пост</title>
</head>
<body>
    <div class="background">
        <section class="header_edit">
            <a class="logo_edit" href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="Логотип компании">
            </a>
            <a href="<?php echo e(url()->previous()); ?>" class="back">
                🠔 Вернуться
            </a>
        </section>
        <form method="POST" action="<?php echo e(route('posts.update', $post)); ?>" class="content">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <input type="text" class="title_input" name="title" value="<?php echo e(old('title', $post->title)); ?>" required>
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div id="editor" class="content_content" contenteditable="true" spellcheck="false"><?php echo e(old('content', $post->content)); ?></div>
            <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="hidden" name="content" id="content-hidden" value="<?php echo e(old('content', $post->content)); ?>">

            <select name="genre" class="genre" required>
                <option value="">Жанр</option>
                <option value="Романтика" <?php echo e($post->genre == 'Романтика' ? 'selected' : ''); ?>>Романтика</option>
                <option value="Фантастика" <?php echo e($post->genre == 'Фантастика' ? 'selected' : ''); ?>>Фантастика</option>
                <option value="Психология" <?php echo e($post->genre == 'Психология' ? 'selected' : ''); ?>>Психология</option>
                <option value="Детектив" <?php echo e($post->genre == 'Детектив' ? 'selected' : ''); ?>>Детектив</option>
            </select>
            <?php $__errorArgs = ['genre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <select name="form" id="form-select" class="forma" required>
                <option value="">Форма</option>
                <option value="стихотворение" <?php echo e($post->form == 'стихотворение' ? 'selected' : ''); ?>>Стихотворение</option>
                <option value="проза" <?php echo e($post->form == 'проза' ? 'selected' : ''); ?>>Проза</option>
            </select>
            <?php $__errorArgs = ['form'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <button type="submit" name="action" value="publish" class="btn_content">Сохранить изменения</button>
            <button type="submit" name="action" value="draft" class="btn_content">В черновик</button>
        </form>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const formSelect = document.getElementById('form-select');
            const editor = document.getElementById('editor');
            const contentHidden = document.getElementById('content-hidden');
            function updateHiddenContent() {
                contentHidden.value = editor.innerText;
            }
            editor.addEventListener('input', updateHiddenContent);
            function updateTextAlign() {
                const value = formSelect.value;
                editor.classList.remove('text-center', 'text-justify');
                if (value === 'стихотворение') editor.classList.add('text-center');
                else if (value === 'проза') editor.classList.add('text-justify');
            }
            updateTextAlign();
            updateHiddenContent();
            formSelect.addEventListener('change', updateTextAlign);
        });
    </script>
</body>
</html><?php /**PATH D:\Diplom\NewWriteNow\WriteNow\resources\views/posts/edit_post.blade.php ENDPATH**/ ?>